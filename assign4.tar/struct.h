#ifndef STRUCT_H
#define STRUCT_H

struct pokemon_trainer {

    int pokeballs;
    int stones;

    int charmander;
    int charmeleon;
    int charizard;
    int torchic;
    int combuskin;
    int blaziken;
    int squirtle;
    int wartortle;
    int blastoise;
    int mudkip;
    int marshtomp;
    int swampert;
    int bulbasaur;
    int ivysaur;
    int venusaur;
    int treecko;
    int grovyle;
    int sceptile;

};

#endif
