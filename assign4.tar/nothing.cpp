#include "./nothing.h"

#include <iostream>

using namespace std;

bool Nothing::prof_good() {

    return true;

}


int Nothing::grant_gift() {

    return 20;

}

void Nothing::hint() {

    return;

}

void Nothing::print_event() {

    cout << "+";

}

void Nothing::destroy() {

    return;

}
